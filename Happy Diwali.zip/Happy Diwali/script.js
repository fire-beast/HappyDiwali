document.addEventListener('DOMContentLoaded', () => {
    // Play audio when the page loads (this may be muted initially due to browser policies)
    const audio = document.getElementById('diwaliAudio');
    audio.loop = true;  // Keep looping the audio
    audio.play().catch(error => {
        console.error('Playback failed:', error);
    });

    const fireworksContainer = document.querySelector('.fireworks');

    function createFirework() {
        const rocket = document.createElement('div');
        rocket.className = 'rocket';
        fireworksContainer.appendChild(rocket);

        // Randomize the horizontal position of the rocket launch
        rocket.style.left = `${Math.random() * 100}vw`;

        // Create the explosion after the rocket reaches its peak
        rocket.addEventListener('animationend', () => {
            createExplosion(rocket.style.left, '30vh');
            rocket.remove();
        });
    }

    function createExplosion(x, y) {
        // Create multiple particles to simulate a burst
        for (let i = 0; i < 20; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            fireworksContainer.appendChild(particle);

            // Randomize the explosion direction for each particle
            const angle = Math.random() * 2 * Math.PI;
            const radius = Math.random() * 50 + 20;
            const dx = Math.cos(angle) * radius + 'px';
            const dy = Math.sin(angle) * radius + 'px';

            particle.style.setProperty('--dx', dx);
            particle.style.setProperty('--dy', dy);
            particle.style.left = x;
            particle.style.top = y;

            // Remove the particle after the animation completes
            setTimeout(() => particle.remove(), 1000);
        }
    }

    // Launch a new firework every 800ms
    setInterval(createFirework, 800);
});
